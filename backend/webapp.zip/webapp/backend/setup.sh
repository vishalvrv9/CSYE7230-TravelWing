#!/bin/bash

sudo apt-get update


sudo DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs npm

sudo DEBIAN_FRONTEND=noninteractive node -v
 
sudo DEBIAN_FRONTEND=noninteractive apt install -y unzip

sudo unzip WebAppRenamed -d WebApp
cd WebApp/backend

sudo npm install

sudo mv /tmp/webapplication.service /etc/systemd/system/webapplication.service