module.exports = {
    openaiConfig: {
        gpt4: {
            model: 'gpt-4',
            temperature: 0.8,
            max_tokens: 2048
        },
        gpt3: {
            model: 'gpt-4',
            temperature: 0.8,
            max_tokens: 2048
        },
    },
  };